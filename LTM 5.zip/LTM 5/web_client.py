"""web_client.py - Client HTTP cho cổng bảng tin của ss_chat_server.py (dùng urllib).

Ví dụ:
    python web_client.py --http-port 8005 history 3
    python web_client.py --http-port 8005 who
    python web_client.py --http-port 8005 post nam Xin chào
"""
import argparse
import json
import sys
from http.client import HTTPException
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import Request, urlopen

TIMEOUT = 10   # giây


def call(base, path, params=None, payload=None):
    """Gửi GET (payload None) hoặc POST JSON; trả về đối tượng JSON của thân phản hồi."""
    url = base + path
    if params:
        url += "?" + urlencode(params)            # tự mã hóa ký tự đặc biệt / tiếng Việt
    if payload is None:
        req = Request(url, method="GET")
    else:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        req = Request(url, data=body, method="POST",
                      headers={"Content-Type": "application/json; charset=utf-8"})
    with urlopen(req, timeout=TIMEOUT) as resp:
        return json.loads(resp.read().decode("utf-8"))


def main():
    ap = argparse.ArgumentParser(description="Client HTTP của bảng tin chat")
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--http-port", type=int, default=8012, help="cổng HTTP của server (mặc định 8012)")
    sub = ap.add_subparsers(dest="command", required=True)

    p_hist = sub.add_parser("history", help="xem n tin gần nhất (mặc định 5)")
    p_hist.add_argument("n", nargs="?", type=int, default=5)
    sub.add_parser("who", help="xem những người đang trực tuyến qua TCP")
    p_post = sub.add_parser("post", help="đăng một tin lên bảng tin")
    p_post.add_argument("name", help="tên người gửi")
    p_post.add_argument("text", nargs="+", help="nội dung (nhiều từ cũng được)")
    args = ap.parse_args()

    base = "http://%s:%d" % (args.host, args.http_port)
    try:
        if args.command == "history":
            items = call(base, "/api/history", params={"n": args.n})
            if not items:
                print("(bảng tin chưa có tin nào)")
            for it in items:
                print("%s: %s" % (it["name"], it["text"]))
        elif args.command == "who":
            names = call(base, "/api/who")
            print("Đang trực tuyến (%d): %s" % (len(names), ", ".join(names)) if names
                  else "(không có ai trực tuyến)")
        else:
            res = call(base, "/api/msg", payload={"name": args.name, "text": " ".join(args.text)})
            print("Đã đăng tin, số thứ tự trên bảng tin: %s" % res["id"])
        return 0

    except HTTPError as e:                  # con của URLError nên phải đứng TRƯỚC
        try:
            msg = json.loads(e.read().decode("utf-8"))["error"]
        except (ValueError, KeyError, TypeError):
            msg = e.reason                  # thân không phải JSON có trường "error"
        print("Lỗi HTTP %d: %s" % (e.code, msg))
    except URLError:
        print("Không kết nối được tới server HTTP %s:%d. Hãy kiểm tra server đã chạy với --http-port chưa."
              % (args.host, args.http_port))
    except TimeoutError:                    # quá hạn khi đang đọc phản hồi (không bọc trong URLError)
        print("Server HTTP không phản hồi trong %d giây." % TIMEOUT)
    except (HTTPException, ConnectionError):   # cổng có server nhưng không nói HTTP (vd cổng chat TCP)
        print("Server trả lời không phải HTTP. Hãy kiểm tra --http-port: đó phải là cổng HTTP, không phải cổng chat TCP.")
    return 1


if __name__ == "__main__":
    sys.exit(main())