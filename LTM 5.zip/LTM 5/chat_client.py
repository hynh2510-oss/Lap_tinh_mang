# chat_client.py

import argparse
import socket

from protocol import SEP, send_line, recv_line, LineTooLong


TIMEOUT = 30


def receive_reply(sock, buf, cmd):
    """
    Đọc đầy đủ phản hồi từ server.

    Với HISTORY|n:
        - Đọc dòng đầu OK|n
        - Sau đó đọc đúng n dòng tiếp theo

    buf được truyền vào từ ngoài và giữ nguyên
    trong suốt phiên làm việc.
    """

    # Đọc dòng trả lời đầu tiên
    first = recv_line(sock, buf)

    if first is None:
        raise EOFError("Server đóng kết nối")

    print(first)

    # ---------------------------------------------------------
    # Chỉ xử lý nhiều dòng khi LỆNH GỬI là HISTORY
    # ---------------------------------------------------------
    if cmd.startswith("HISTORY" + SEP):

        parts = first.split(SEP, 1)

        if len(parts) == 2 and parts[0] == "OK":

            if parts[1].isdigit():
                count = int(parts[1])

                # Đọc đúng count dòng HISTORY
                for _ in range(count):

                    line = recv_line(sock, buf)

                    if line is None:
                        raise EOFError(
                            "Server đóng kết nối khi HISTORY chưa đủ dòng"
                        )

                    print(line)

    return first


def main():

    parser = argparse.ArgumentParser()

    parser.add_argument(
        "--host",
        default="127.0.0.1"
    )

    parser.add_argument(
        "--port",
        type=int,
        default=9012
    )

    args = parser.parse_args()

    try:

        # -----------------------------------------------------
        # 1. Mở một kết nối duy nhất
        # -----------------------------------------------------
        with socket.create_connection(
            (args.host, args.port),
            timeout=TIMEOUT
        ) as sock:

            # -------------------------------------------------
            # 2. Đặt timeout
            # -------------------------------------------------
            sock.settimeout(TIMEOUT)

            print(
                "Đã kết nối server %s:%d."
                % (args.host, args.port)
            )

            # -------------------------------------------------
            # 3. Buffer được tạo MỘT LẦN
            # -------------------------------------------------
            buf = bytearray()

            # -------------------------------------------------
            # 4. Vòng lặp hỏi - đáp
            # -------------------------------------------------
            while True:

                try:

                    # Nhập lệnh
                    cmd = input("> ")

                    # Gửi lệnh
                    send_line(sock, cmd)

                    # Đọc phản hồi
                    reply = receive_reply(
                        sock,
                        buf,
                        cmd
                    )

                    # Thoát khi nhận BYE
                    if reply == "BYE":

                        print(
                            "Kết thúc phiên làm việc."
                        )

                        break

                except LineTooLong:

                    print(
                        "Lỗi: Dòng quá dài. "
                        "Hãy nhập lệnh ngắn hơn."
                    )

                except socket.timeout:

                    print(
                        "Server không phản hồi trong thời gian "
                        "cho phép. Hãy kiểm tra server hoặc mạng."
                    )

                    break

                except ConnectionError:

                    print(
                        "Kết nối với server bị mất. "
                        "Hãy kiểm tra mạng và kết nối lại."
                    )

                    break

    # ---------------------------------------------------------
    # 5. Bắt riêng các lỗi theo yêu cầu
    # ---------------------------------------------------------

    except ConnectionRefusedError:

        print(
            "Không thể kết nối tới server. "
            "Hãy kiểm tra server đã chạy chưa "
            "và port có đúng không."
        )

    except TimeoutError:

        print(
            "Kết nối bị quá thời gian chờ. "
            "Kiểm tra địa chỉ IP, port hoặc mạng rồi thử lại."
        )

    except ConnectionError:

        print(
            "Không thể thiết lập kết nối với server. "
            "Hãy kiểm tra mạng và địa chỉ server."
        )

    except EOFError:

        print(
            "Server đóng kết nối bất ngờ. "
            "Hãy kiểm tra trạng thái server và thử lại."
        )

    except KeyboardInterrupt:

        print(
            "\nNgười dùng yêu cầu dừng client."
        )


if __name__ == "__main__":
    main()
