"""mf_chat_client.py - Client chat dùng create_connection() và makefile().

Chạy: python mf_chat_client.py --host 127.0.0.1 --port 9012
Gõ lệnh giao thức (LOGIN|tên, MSG|all|nội dung, HISTORY|n, WHO, QUIT)
rồi Enter; client in phản hồi của server.
"""
import argparse
import socket

from protocol import SEP, MAX_LINE

TIMEOUT = 30   # giây; dùng cho cả lúc kết nối lẫn lúc chờ phản hồi


def read_one(f):
    """Đọc MỘT dòng từ tệp-socket f. Chuỗi rỗng nghĩa là server đã đóng kết nối."""
    line = f.readline()
    if line == "":
        raise EOFError("Server đóng kết nối")
    return line.rstrip("\r\n")


def receive_reply(f, cmd):
    """In phản hồi của server cho lệnh cmd, trả về dòng đầu tiên.

    HISTORY|n: dòng đầu là OK|<k> (k <= n, là số tin thực có), sau đó đọc
    ĐÚNG k dòng MSG|... nữa. Mọi lệnh khác chỉ có một dòng trả lời.
    """
    first = read_one(f)
    print(first)

    if cmd.startswith("HISTORY" + SEP):
        kind, _, count = first.partition(SEP)
        if kind == "OK" and count.isascii() and count.isdigit():
            for _ in range(int(count)):
                print(read_one(f))        # server đóng giữa chừng -> EOFError
    return first


def chat_loop(f):
    """Vòng lặp hỏi - đáp trên tệp-socket f."""
    while True:
        try:
            cmd = input("> ")
        except EOFError:                  # Ctrl+Z / Ctrl+D ở dấu nhắc: lỗi từ bàn phím, không phải từ server
            print("Đã hết dữ liệu nhập, đóng client.")
            return

        if len(cmd.encode("utf-8")) > MAX_LINE:     # tránh bị server đóng phiên với ERR|7
            print(f"Lệnh dài quá {MAX_LINE} byte. Hãy nhập lệnh ngắn hơn.")
            continue

        print(cmd, file=f, flush=True)      # gửi: thêm "\n" và đẩy đi ngay
        if receive_reply(f, cmd) == "BYE":
            print("Kết thúc phiên làm việc.")
            return


def main():
    ap = argparse.ArgumentParser(description="Client chat")
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=9012)
    args = ap.parse_args()

    connected = False    # phân biệt TimeoutError lúc kết nối với lúc chờ phản hồi
    try:
        with socket.create_connection((args.host, args.port), timeout=TIMEOUT) as sock:
            connected = True
            sock.settimeout(TIMEOUT)
            with sock.makefile("rw", encoding="utf-8", newline="\n") as f:
                print("Đã kết nối server %s:%d." % (args.host, args.port))
                chat_loop(f)

    except TimeoutError:
        if connected:
            print("Server không phản hồi trong %d giây. Hãy kiểm tra server hoặc mạng." % TIMEOUT)
        else:
            print("Kết nối tới server quá thời gian chờ. Hãy kiểm tra địa chỉ IP, cổng hoặc mạng.")
    except ConnectionRefusedError:      # con của ConnectionError nên phải đứng TRƯỚC
        print("Không kết nối được tới server. Hãy kiểm tra server đã chạy chưa và cổng có đúng không.")
    except ConnectionError:
        if connected:
            print("Kết nối với server bị mất. Hãy kiểm tra server hoặc mạng rồi kết nối lại.")
        else:
            print("Không thể thiết lập kết nối với server. Hãy kiểm tra mạng và địa chỉ server.")
    except EOFError:
        print("Server đã đóng kết nối. Hãy kiểm tra trạng thái server rồi chạy lại client.")
    except KeyboardInterrupt:
        print("\nNgười dùng yêu cầu dừng client.")
    except OSError as e:                # còn lại: sai tên máy (gaierror), mạng không tới được...
        print("Không kết nối được tới %s:%d (%s)." % (args.host, args.port, e))


if __name__ == "__main__":
    main()