"""ss_chat_server.py - Server chat dùng socketserver (tuần tự hoặc đa luồng)
kèm cổng HTTP cho bảng tin, chạy cùng một tiến trình.

Logic giao thức, ONLINE, BOARD dùng lại từ chat_server.py (Bài tập 3).

Chạy:
    python ss_chat_server.py                          # tuần tự, cổng chat 9012
    python ss_chat_server.py --threads                # đa luồng
    python ss_chat_server.py --threads --http-port 8012
    python ss_chat_server.py --threads --delay 2      # giả lập server xử lý chậm
"""
import argparse
import json
import logging
import socket
import socketserver
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlsplit

from chat_server import (
    BOARD, LOCK, ONLINE, Session, handle_request, leave, valid_name,
)
from protocol import (
    ENCODING, ERR_TOO_LONG, MAX_CONTENT, RESERVED_NAMES,
    LineTooLong, err, read_line, write_line,
)

log = logging.getLogger("ss_chat")


# ======================================================================
# Mục 2 - Lớp xử lý và lớp server (TCP, socketserver)
# ======================================================================
class ChatHandler(socketserver.StreamRequestHandler):
    timeout = 300          # giây; client im lặng quá lâu bị ngắt
    delay = 0.0            # giây; gán từ --delay trong main()

    def handle(self):
        addr = self.client_address
        sess = Session(addr)
        log.info("Kết nối mới từ %s:%d", *addr)
        try:
            while not sess.closing:
                try:
                    line = read_line(self.rfile)
                except LineTooLong:
                    log.warning("Dòng quá dài từ %s:%d -> gửi ERR|%d rồi đóng phiên",
                                addr[0], addr[1], ERR_TOO_LONG)
                    write_line(self.wfile, err(ERR_TOO_LONG))
                    break
                if line is None:
                    log.info("Client %s:%d đóng kết nối (không gửi QUIT)", *addr)
                    break
                log.info("Nhận từ %s:%d: %r", addr[0], addr[1], line)
                if self.delay > 0:
                    time.sleep(self.delay)         # giả lập xử lý chậm
                for reply in handle_request(line, sess):
                    write_line(self.wfile, reply)
        except socket.timeout:
            log.warning("Client %s:%d im lặng quá %ds -> ngắt phiên",
                        addr[0], addr[1], self.timeout)
        finally:
            leave(sess)                            # luôn xóa tên khỏi ONLINE
            log.info("Đóng phiên %s:%d (user=%s)", addr[0], addr[1], sess.name)


class ChatServer(socketserver.TCPServer):
    allow_reuse_address = True
    request_queue_size = 16          # đủ cho 10 client cùng chờ ở Phần C

    def handle_error(self, request, client_address):
        """Ghi MỘT dòng log thay cho vết lỗi (traceback) mặc định."""
        e = sys.exc_info()[1]
        log.error("Lỗi khi phục vụ %s:%d - %s: %s",
                  client_address[0], client_address[1], type(e).__name__, e)


# ======================================================================
# Mục 3 - Đa luồng bằng mix-in (mix-in đứng TRƯỚC lớp server)
# ======================================================================
class ThreadedChatServer(socketserver.ThreadingMixIn, ChatServer):
    daemon_threads = True


# ======================================================================
# Mục 4 - Cổng HTTP cho bảng tin
# ======================================================================
MAX_BODY = 64 * 1024        # giới hạn thân yêu cầu POST


class BoardHandler(BaseHTTPRequestHandler):
    server_version = "BoardHTTP/1.0"

    def log_message(self, fmt, *args):             # đưa log HTTP vào logging (có tên luồng)
        log.info("HTTP %s:%d %s", self.client_address[0], self.client_address[1], fmt % args)

    def send_json(self, code, obj):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def send_error(self, code, message=None, explain=None):
        """Lỗi do http.server tự sinh (vd 501) cũng trả JSON, không trả HTML."""
        self.send_json(code, {"error": message or self.responses.get(code, ("Lỗi",))[0]})

    def bad(self, why):
        self.send_json(400, {"error": why})

    # ---- GET /api/history?n=<n>, GET /api/who ----
    def do_GET(self):
        url = urlsplit(self.path)
        if url.path == "/api/history":
            raw = parse_qs(url.query).get("n", ["5"])[0]
            n = int(raw) if raw.isascii() and raw.isdigit() and len(raw) <= 9 else 5
            with LOCK:
                items = BOARD[-n:] if n > 0 else []
            self.send_json(200, [{"name": who, "text": text} for who, text in items])
        elif url.path == "/api/who":
            with LOCK:
                names = sorted(ONLINE.values(), key=str.lower)
            self.send_json(200, names)
        else:
            self.send_json(404, {"error": "Không tìm thấy đường dẫn"})

    # ---- POST /api/msg  {"name": ..., "text": ...} ----
    def do_POST(self):
        if urlsplit(self.path).path != "/api/msg":
            return self.send_json(404, {"error": "Không tìm thấy đường dẫn"})
        try:
            length = int(self.headers.get("Content-Length", ""))
        except ValueError:
            return self.bad("Thiếu hoặc sai Content-Length")
        if not 0 <= length <= MAX_BODY:
            return self.bad("Thân yêu cầu quá lớn")
        try:
            data = json.loads(self.rfile.read(length).decode("utf-8"))
        except ValueError:                          # gồm JSONDecodeError, UnicodeDecodeError
            return self.bad("JSON hỏng")
        if (not isinstance(data, dict)
                or not isinstance(data.get("name"), str)
                or not isinstance(data.get("text"), str)):
            return self.bad("Thiếu trường name/text (phải là chuỗi)")
        name, text = data["name"], data["text"]
        if not valid_name(name) or name.lower() in RESERVED_NAMES:
            return self.bad("Tên sai luật đặt tên của LOGIN")
        if not text.strip():
            return self.bad("Nội dung rỗng")
        if "\n" in text or "\r" in text:
            return self.bad("Nội dung có ký tự xuống dòng")
        if len(text.encode(ENCODING)) > MAX_CONTENT:
            return self.bad(f"Nội dung quá {MAX_CONTENT} byte")
        with LOCK:
            BOARD.append((name, text))
            new_id = len(BOARD)
        self.send_json(201, {"id": new_id})


# ======================================================================
# main()
# ======================================================================
def main():
    ap = argparse.ArgumentParser(description="Server chat socketserver + HTTP bảng tin")
    ap.add_argument("--host", default="0.0.0.0", help="địa chỉ bind (mặc định 0.0.0.0)")
    ap.add_argument("--port", type=int, default=9012, help="cổng chat TCP (9000 + mã nhóm)")
    ap.add_argument("--http-port", type=int, default=None,
                    help="cổng HTTP bảng tin (8000 + mã nhóm); bỏ trống = không bật HTTP")
    ap.add_argument("--threads", action="store_true", help="phục vụ đa luồng (mặc định: tuần tự)")
    ap.add_argument("--delay", type=float, default=0.0,
                    help="giây ngủ trước khi trả lời mỗi lệnh (mặc định 0)")
    args = ap.parse_args()

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(threadName)s] [%(levelname)s] %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
        handlers=[logging.StreamHandler(),
                  logging.FileHandler("ss_chat_server.log", encoding="utf-8")],
    )

    ChatHandler.delay = args.delay
    server_cls = ThreadedChatServer if args.threads else ChatServer
    try:
        chat = server_cls((args.host, args.port), ChatHandler)
        web = None
        if args.http_port is not None:
            try:
                web = ThreadingHTTPServer((args.host, args.http_port), BoardHandler)
            except OSError:
                chat.server_close()
                raise
    except OSError as e:
        raise SystemExit(f"Không mở được cổng: {e}")

    log.info("Chat TCP tại %s:%d (%s, delay=%gs)", args.host, args.port,
             "đa luồng" if args.threads else "tuần tự", args.delay)
    if web:
        threading.Thread(target=web.serve_forever, daemon=True).start()
        log.info("HTTP bảng tin tại %s:%d", args.host, args.http_port)

    with chat:
        try:
            chat.serve_forever()              # luồng chính phục vụ chat
        except KeyboardInterrupt:
            log.info("Dừng server (Ctrl+C)")
        finally:
            if web:
                web.shutdown()                # gọi từ luồng khác luồng của web
                web.server_close()


if __name__ == "__main__":
    main()
