"""test_bt5.py - Kiểm thử Bài tập 5: in Đạt / SAI cho từng ca.

Bật server trước (hai lần chạy, ghi cả hai cột vào Bảng 2):
    python ss_chat_server.py --threads --http-port 8012     # cột "Server --threads"
    python ss_chat_server.py --http-port 8012                # cột "Server tuần tự"
Rồi chạy:
    python test_bt5.py --port 9012 --http-port 8012

Nhóm (a): tám lệnh dồn vào một sendall(); (b): hai client cùng lúc;
(c): cổng HTTP và sự đồng bộ với TCP, cộng các ca lỗi.
"""
import argparse
import http.client
import json
import random
import socket
import string
import sys
import time

TIMEOUT = 3.0
RESULTS = []     # (tt, nhóm, mục đích, ok)


def tag():
    return "".join(random.choices(string.ascii_lowercase + string.digits, k=4))


def record(tt, group, purpose, ok, why=""):
    RESULTS.append((tt, group, purpose, ok))
    print("%2d (%s) %s: %s" % (tt, group, purpose, "Đạt" if ok else "SAI"))
    if not ok and why:
        print("      -> " + why)


def run_case(tt, group, purpose, fn):
    """Chạy fn() -> (ok, lý do); mọi ngoại lệ (timeout, mất kết nối...) tính là SAI."""
    try:
        ok, why = fn()
    except Exception as e:
        ok, why = False, "%s: %s" % (type(e).__name__, e)
    record(tt, group, purpose, ok, why)


# ---------------- Trợ giúp TCP / HTTP ----------------
class Tcp:
    def __init__(self, host, port):
        self.sock = socket.create_connection((host, port), timeout=TIMEOUT)
        self.f = self.sock.makefile("rw", encoding="utf-8", newline="\n")

    def send(self, line):
        print(line, file=self.f, flush=True)

    def read(self, timeout=TIMEOUT):
        self.sock.settimeout(timeout)
        line = self.f.readline()
        if line == "":
            raise EOFError("server đóng kết nối")
        return line.rstrip("\r\n")

    def close(self):
        for obj in (self.f, self.sock):
            try:
                obj.close()
            except Exception:
                pass


def tcp_history(host, port, n=100):
    """Đăng nhập một client TCP tạm rồi lấy HISTORY|n; trả về danh sách các dòng MSG|..."""
    t = Tcp(host, port)
    try:
        t.send("LOGIN|t_h" + tag())
        t.read()
        t.send("HISTORY|%d" % n)
        k = int(t.read().partition("|")[2])
        lines = [t.read() for _ in range(k)]
        t.send("QUIT")
        return lines
    finally:
        t.close()


def http_call(host, port, method, path, body=None):
    c = http.client.HTTPConnection(host, port, timeout=TIMEOUT)
    try:
        headers = {}
        if body is not None:
            headers["Content-Type"] = "application/json; charset=utf-8"
        c.request(method, path, body=body, headers=headers)
        r = c.getresponse()
        raw = r.read()
        try:
            data = json.loads(raw.decode("utf-8"))
        except ValueError:
            data = None
        return r.status, data
    finally:
        c.close()


def post_msg(host, port, name, text):
    body = json.dumps({"name": name, "text": text}, ensure_ascii=False).encode("utf-8")
    return http_call(host, port, "POST", "/api/msg", body)


# ---------------- Nhóm (a): tám lệnh trong một sendall() ----------------
def group_a(host, port):
    n = tag()
    a, b, text = "t_a" + n, "t_x" + n, "Xin chào " + n
    cmds = ["MSG|all|chào", "LOGIN|" + a, "LOGIN|" + b, "MSG|all|" + text,
            "HISTORY|1", "FOO", "WHO", "QUIT"]
    lines = []
    t = None
    try:
        t = Tcp(host, port)
        t.sock.sendall("".join(c + "\n" for c in cmds).encode("utf-8"))   # TẤT CẢ trong một lần gửi
        while True:
            try:
                lines.append(t.read())
            except (EOFError, TimeoutError):
                break
    except Exception as e:
        print("   (lỗi nhóm a: %s: %s)" % (type(e).__name__, e))
    finally:
        if t:
            t.close()

    def at(i):
        return lines[i] if i < len(lines) else None

    def eq(i, want):
        return (at(i) == want, "nhận %r, mong đợi %r" % (at(i), want))

    def who_ok():
        got = at(7) or ""
        return (got.startswith("WHO|") and a in got[4:].split(","), "nhận %r" % got)

    def hist_ok():
        return (at(4) == "OK|1" and at(5) == "MSG|%s|%s" % (a, text),
                "nhận %r và %r" % (at(4), at(5)))

    cases = [
        (1, "Chặn sai trình tự (MSG khi chưa LOGIN)", lambda: eq(0, "ERR|4")),
        (2, "LOGIN hợp lệ", lambda: eq(1, "OK|Chào " + a)),
        (3, "LOGIN lần hai bị từ chối", lambda: eq(2, "ERR|3")),
        (4, "MSG khi đã đăng nhập", lambda: eq(3, "OK|Đã lưu")),
        (5, "HISTORY|1 trả OK|1 và đúng một dòng MSG", hist_ok),
        (6, "Lệnh lạ FOO", lambda: eq(6, "ERR|5")),
        (7, "WHO thấy tên mình", who_ok),
        (8, "QUIT trả BYE rồi server đóng", lambda: eq(8, "BYE")),
    ]
    # Chỉ số dòng trả lời: 0 ERR|4, 1 OK, 2 ERR|3, 3 OK|Đã lưu, 4-5 HISTORY, 6 ERR|5 (FOO), 7 WHO, 8 BYE
    for tt, purpose, fn in cases:
        run_case(tt, "a", purpose, fn)


# ---------------- Nhóm (b): hai client cùng lúc ----------------
def group_b(host, port):
    n = tag()
    a, b = "t_a" + n, "t_b" + n
    A = B = None
    try:
        A = Tcp(host, port)
        A.send("LOGIN|" + a)
        if not A.read().startswith("OK|"):
            raise RuntimeError("A không đăng nhập được")
        B = Tcp(host, port)           # TCP vẫn nhận kết nối (hàng đợi listen) kể cả khi server bận
        state = {}

        def b_login():
            t0 = time.time()
            B.send("LOGIN|" + b)
            try:
                reply = B.read(timeout=1.0)
            except TimeoutError:
                return False, "quá 1 giây vẫn chưa có trả lời (server đang bận phục vụ A)"
            dt = time.time() - t0
            state["ok"] = reply.startswith("OK|")
            return (state["ok"] and dt <= 1.0, "nhận %r sau %.2f s" % (reply, dt))

        def a_who():
            A.send("WHO")
            names = A.read().partition("|")[2].split(",")
            return (a in names and b in names, "WHO của A: %s" % names)

        run_case(9, "b", "B vào khi A còn giữ kết nối (OK trong 1 s)", b_login)
        run_case(10, "b", "WHO của A thấy cả hai tên", a_who)
    except Exception as e:
        for tt, purpose in ((9, "B vào khi A còn giữ kết nối (OK trong 1 s)"),
                            (10, "WHO của A thấy cả hai tên")):
            if not any(r[0] == tt for r in RESULTS):
                record(tt, "b", purpose, False, "%s: %s" % (type(e).__name__, e))
    finally:
        for c in (B, A):              # đóng B trước, A sau
            if c:
                try:
                    c.send("QUIT")
                except Exception:
                    pass
                c.close()


# ---------------- Nhóm (c): HTTP ----------------
def group_c(host, port, hport):
    n = tag()

    def post_then_tcp():
        name, text = "web" + n, "POST-" + n
        status, _ = post_msg(host, hport, name, text)
        if status != 201:
            return False, "POST trả %s, mong đợi 201" % status
        found = "MSG|%s|%s" % (name, text) in tcp_history(host, port)
        return found, "tin POST không thấy trong HISTORY của client TCP"

    def tcp_then_get():
        name, text = "t_c" + n, "TCP-" + n
        t = Tcp(host, port)
        try:
            t.send("LOGIN|" + name)
            t.read()
            t.send("MSG|all|" + text)
            if not t.read().startswith("OK|"):
                return False, "MSG qua TCP bị từ chối"
            t.send("QUIT")
        finally:
            t.close()
        status, data = http_call(host, hport, "GET", "/api/history?n=100")
        found = status == 200 and {"name": name, "text": text} in (data or [])
        return found, "tin gửi qua TCP không thấy trong GET /api/history"

    def bad_json():
        status, data = http_call(host, hport, "POST", "/api/msg", "{hỏng".encode("utf-8"))
        return (status == 400 and bool(data and data.get("error")), "trả %s %s" % (status, data))

    def newline_text():
        status, data = post_msg(host, hport, "web" + n, "dòng 1\ndòng 2")
        return (status == 400 and bool(data and data.get("error")), "trả %s %s" % (status, data))

    def unknown_path():
        status, data = http_call(host, hport, "GET", "/api/khong-co")
        return (status == 404 and bool(data and data.get("error")), "trả %s %s" % (status, data))

    def reserved_name():
        status, data = post_msg(host, hport, "all", "x")
        return (status == 400, "trả %s %s" % (status, data))

    run_case(11, "c", "POST /api/msg hiện trong HISTORY của TCP", post_then_tcp)
    run_case(12, "c", "MSG qua TCP hiện trong GET /api/history", tcp_then_get)
    run_case(13, "c", "JSON hỏng -> 400", bad_json)
    run_case(14, "c", "Nội dung có xuống dòng -> 400", newline_text)
    run_case(15, "c", "Đường dẫn lạ -> 404", unknown_path)
    run_case(16, "c", "Tên dành riêng 'all' -> 400", reserved_name)


def main():
    ap = argparse.ArgumentParser(description="Kiểm thử Bài tập 5")
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=9012, help="cổng chat TCP")
    ap.add_argument("--http-port", type=int, default=8012, help="cổng HTTP")
    args = ap.parse_args()

    try:
        socket.create_connection((args.host, args.port), timeout=2).close()
    except OSError as e:
        raise SystemExit("Không kết nối được tới server %s:%d (%s). Hãy bật server trước."
                         % (args.host, args.port, e))

    group_a(args.host, args.port)
    group_b(args.host, args.port)
    group_c(args.host, args.port, args.http_port)

    passed = sum(1 for r in RESULTS if r[3])
    print("\nTổng: %d/%d ca Đạt, %d ca SAI" % (passed, len(RESULTS), len(RESULTS) - passed))
    return 0 if passed == len(RESULTS) else 1


if __name__ == "__main__":
    sys.exit(main())