
# test_server.py

import socket

from protocol import (
    recv_line,
    err,
    ERR_NOT_LOGGED_IN,
    ERR_BAD_NAME,
    ERR_ALREADY_LOGGED_IN,
    ERR_SYNTAX,
)


HOST = "127.0.0.1"
PORT = 9012


def run_case(no, title, commands, expected_prefixes):

    print(f"\n[{no}] {title}")

    payload = ""

    for cmd in commands:
        payload += cmd + "\n"

    actual = []

    try:
        with socket.create_connection((HOST, PORT), timeout=5) as sock:

            # Mỗi test CHỈ có đúng 1 lần sendall()
            sock.sendall(payload.encode("utf-8"))

            buf = bytearray()

            # Chỉ đọc đúng số dòng mà test mong đợi
            for _ in range(len(expected_prefixes)):

                line = recv_line(sock, buf)

                if line is None:
                    break

                actual.append(line)

    except Exception as e:
        print("SAI:", e)
        return

    ok = True

    if len(actual) != len(expected_prefixes):
        ok = False
    else:
        for i, exp in enumerate(expected_prefixes):
            if not actual[i].startswith(exp):
                ok = False

    print("Expected:", expected_prefixes)
    print("Actual  :", actual)

    if ok:
        print("===> ĐẠT")
    else:
        print("===> SAI")


def main():

    # 1
    # Dữ liệu không hợp lệ:
    # MSG khi chưa đăng nhập
    run_case(
        1,
        "MSG khi chưa login",
        [
            "MSG|all|hello",
        ],
        [
            err(ERR_NOT_LOGGED_IN),
        ]
    )

    # 2
    # Dữ liệu không hợp lệ:
    # LOGIN với tên rỗng
    run_case(
        2,
        "Tên rỗng",
        [
            "LOGIN|",
        ],
        [
            err(ERR_BAD_NAME),
        ]
    )

    # 3
    # Login thành công
    run_case(
        3,
        "Login thành công",
        [
            "LOGIN|Alice",
            "QUIT"
        ],
        [
            "OK|Chào Alice",
            "BYE"
        ]
    )

    # 4
    # Dữ liệu không hợp lệ:
    # Login lần thứ hai trong cùng một phiên
    run_case(
        4,
        "Login hai lần",
        [
            "LOGIN|Bob",
            "LOGIN|C",
        ],
        [
            "OK|Chào Bob",
            err(ERR_ALREADY_LOGGED_IN),
        ]
    )

    # 5
    # Dữ liệu không hợp lệ:
    # MSG không gửi đến "all"
    run_case(
        5,
        "Sai cú pháp MSG",
        [
            "LOGIN|Minh",
            "MSG|abc|hello",
        ],
        [
            "OK|Chào Minh",
            err(ERR_SYNTAX),
        ]
    )

    # 6
    # Gửi tin hợp lệ
    run_case(
        6,
        "Gửi tin hợp lệ",
        [
            "LOGIN|Lan",
            "MSG|all|hello world",
            "QUIT"
        ],
        [
            "OK|Chào Lan",
            "OK|Đã lưu",
            "BYE"
        ]
    )

    # 7
    # Kiểm tra HISTORY.
    # Hai tin nhắn được tạo ngay trong test này,
    # sau đó HISTORY|2 phải trả về đúng 2 tin đó.
    run_case(
        7,
        "History",
        [
            "LOGIN|Reader",
            "MSG|all|Tin thu nhat",
            "MSG|all|Tin thu hai",
            "HISTORY|2",
        ],
        [
            "OK|Chào Reader",
            "OK|Đã lưu",
            "OK|Đã lưu",
            "OK|2",
            "MSG|Reader|Tin thu nhat",
            "MSG|Reader|Tin thu hai",
        ]
    )


if __name__ == "__main__":
    main()

