"""chat_server.py - Server chat TUẦN TỰ: mỗi lúc chỉ phục vụ một client.

Chạy: python chat_server.py --host 0.0.0.0 --port 9000
Bốn lệnh: LOGIN|<tên>, MSG|all|<nội dung>, HISTORY|<n>, QUIT
"""
import argparse
import logging
import socket

from protocol import (

    SEP, MAX_NAME, MAX_CONTENT, ENCODING, RESERVED_NAMES,
    ERR_BAD_NAME, ERR_NAME_TAKEN, ERR_ALREADY_LOGGED_IN, ERR_NOT_LOGGED_IN,
    ERR_UNKNOWN_CMD, ERR_SYNTAX, ERR_TOO_LONG,
    LineTooLong, err, send_line, recv_line,
)

log = logging.getLogger("chat")

IDLE_TIMEOUT = 120  # giây; client im lặng quá lâu sẽ bị ngắt để không chặn server tuần tự

# ---- Dữ liệu dùng chung giữa các phiên ----
ONLINE = set()   # tên (viết thường) của các phiên đang trực tuyến
BOARD = []       # bảng tin chung: danh sách (tên, nội dung)


class Session:
    """Trạng thái của MỘT phiên. name is None  <=>  chưa đăng nhập."""

    def __init__(self, addr):
        self.addr = addr
        self.name = None
        self.closing = False   # True sau khi xử lý QUIT


def handle_request(line, sess):
    """Xử lý một dòng lệnh, trả về danh sách các dòng cần gửi lại cho client.

    Hàm không đụng tới socket nên có thể kiểm thử riêng; lệnh sai luôn được
    trả bằng mã lỗi, không ném ngoại lệ ra ngoài.
    """
    cmd, _, rest = line.partition(SEP)

    # --- QUIT: hợp lệ ở mọi trạng thái ---
    if cmd == "QUIT":
        if SEP in line:                       # "QUIT|abc"
            return [err(ERR_SYNTAX)]
        sess.closing = True
        return ["BYE"]

    # --- LOGIN ---
    if cmd == "LOGIN":
        if sess.name is not None:
            return [err(ERR_ALREADY_LOGGED_IN)]
        name = rest
        if not name.strip() or len(name) > MAX_NAME or SEP in name:
            return [err(ERR_BAD_NAME)]
        key = name.lower()
        if key in RESERVED_NAMES or key in ONLINE:
            return [err(ERR_NAME_TAKEN)]
        sess.name = name
        ONLINE.add(key)
        return [f"OK{SEP}Chào {name}"]

    # --- MSG, HISTORY: cần đăng nhập ---
    if cmd in ("MSG", "HISTORY"):
        if sess.name is None:
            return [err(ERR_NOT_LOGGED_IN)]

        if cmd == "MSG":
            parts = line.split(SEP, 2)        # nội dung được phép chứa "|"
            if len(parts) != 3 or parts[1] != "all":
                return [err(ERR_SYNTAX)]
            content = parts[2]
            if not content.strip() or len(content.encode(ENCODING)) > MAX_CONTENT:
                return [err(ERR_SYNTAX)]
            BOARD.append((sess.name, content))
            return [f"OK{SEP}Đã lưu"]

        # HISTORY|<n>
        if not (rest.isascii() and rest.isdigit()) or int(rest) == 0:
            return [err(ERR_SYNTAX)]
        items = BOARD[-int(rest):]
        return [f"OK{SEP}{len(items)}"] + [f"MSG{SEP}{who}{SEP}{text}" for who, text in items]

    return [err(ERR_UNKNOWN_CMD)]


def handle_client(conn, addr):
    """Phục vụ trọn một phiên. Mọi lỗi của client được chặn tại đây."""
    sess = Session(addr)
    buf = bytearray()
    log.info("Kết nối mới từ %s:%d", *addr)
    try:
        with conn:                                   # 'with' cho socket phiên
            conn.settimeout(IDLE_TIMEOUT)
            while not sess.closing:
                try:
                    line = recv_line(conn, buf)
                except LineTooLong:
                    log.warning("Dòng quá dài từ %s:%d -> gửi ERR|%d rồi đóng phiên",
                                addr[0], addr[1], ERR_TOO_LONG)
                    send_line(conn, err(ERR_TOO_LONG))
                    break
                if line is None:
                    log.info("Client %s:%d đóng kết nối (không gửi QUIT)", *addr)
                    break
                log.info("Nhận từ %s:%d: %r", addr[0], addr[1], line)
                for reply in handle_request(line, sess):
                    send_line(conn, reply)
    except socket.timeout:                           # phải đặt TRƯỚC OSError
        log.warning("Client %s:%d im lặng quá %ds -> ngắt phiên", addr[0], addr[1], IDLE_TIMEOUT)
    except OSError as e:                             # rút dây, reset, broken pipe...
        log.error("Lỗi socket với %s:%d: %s", addr[0], addr[1], e)
    except Exception:                                # lỗi bất ngờ vẫn không làm chết server
        log.exception("Lỗi không lường trước với %s:%d", *addr)
    finally:
        if sess.name is not None:                    # luôn dọn tên, kể cả khi client rút dây
            ONLINE.discard(sess.name.lower())
        log.info("Đóng phiên %s:%d (user=%s)", addr[0], addr[1], sess.name)


def create_listener(host, port):
    """Tạo socket lắng nghe (đã setsockopt -> bind -> listen)."""
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)   # trước bind()
        s.bind((host, port))
        s.listen()
    except OSError:
        s.close()
        raise
    log.info("Đã mở cổng, đang lắng nghe tại %s:%d", *s.getsockname())
    return s


def serve_forever(listener):
    """Vòng lặp tuần tự: accept -> phục vụ xong client này mới accept client kế."""
    listener.settimeout(1.0)          # để Ctrl+C có tác dụng cả trên Windows
    while True:
        try:
            conn, addr = listener.accept()
        except socket.timeout:
            continue
        handle_client(conn, addr)


def main():
    ap = argparse.ArgumentParser(description="Server chat tuần tự")
    ap.add_argument("--host", default="0.0.0.0", help="địa chỉ bind (mặc định 0.0.0.0)")
    ap.add_argument("--port", type=int, default=9012, help="cổng lắng nghe (mặc định 9000)")
    args = ap.parse_args()

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
        handlers=[logging.StreamHandler(),
                  logging.FileHandler("chat_server.log", encoding="utf-8")],
    )
    try:
        with create_listener(args.host, args.port) as listener:   # 'with' cho socket lắng nghe
            serve_forever(listener)
    except KeyboardInterrupt:
        log.info("Nhận Ctrl+C - server dừng an toàn.")
    except OSError as e:
        log.error("Không mở được %s:%d - %s", args.host, args.port, e)


if __name__ == "__main__":
    main()