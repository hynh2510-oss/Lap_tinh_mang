import socket

# --- phia_gui.py ---[cite: 1]
def main():
    HOST = '127.0.0.1'
    PORT = 9012  # Đổi thành cổng của nhóm bạn

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.connect((HOST, PORT))
        print(f"Đã kết nối tới {HOST}:{PORT}")
        
        for i in range(1, 4): #[cite: 1]
            s.sendall(f"MSG|all|tin {i}\n".encode("utf-8")) #[cite: 1]
            
        s.sendall(b"x" * 5_000_000) # rồi đóng socket[cite: 1]
        print("Đã gửi xong dữ liệu và đóng kết nối.")

if __name__ == "__main__":
    main()