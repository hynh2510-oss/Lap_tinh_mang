"""protocol.py - Hằng số và hàm dùng chung cho server lẫn client.

Giao thức chat dạng dòng: mỗi thông điệp là một dòng văn bản UTF-8 kết thúc
bằng "\\n"; các trường trong dòng cách nhau bởi ký tự "|".
"""

ENCODING = "utf-8"
SEP = "|"            # ký tự phân cách các trường
MAX_LINE = 1024      # số byte tối đa của một dòng (không tính "\n")
MAX_NAME = 20        # độ dài tối đa của tên đăng nhập (ký tự)
MAX_CONTENT = 900    # độ dài tối đa của nội dung tin nhắn (byte UTF-8)
RESERVED_NAMES = {"all", "server", "system"}   # tên dành riêng

# ---- Bảng mã lỗi ----
ERR_BAD_NAME = 1           # tên rỗng / quá 20 ký tự / chứa "|"
ERR_NAME_TAKEN = 2         # tên đã có người dùng hoặc là tên dành riêng
ERR_ALREADY_LOGGED_IN = 3  # đã đăng nhập rồi mà còn gửi LOGIN
ERR_NOT_LOGGED_IN = 4      # chưa đăng nhập mà gửi MSG / HISTORY
ERR_UNKNOWN_CMD = 5        # lệnh không tồn tại
ERR_SYNTAX = 6             # sai cú pháp / tham số
ERR_TOO_LONG = 7           # dòng vượt MAX_LINE (server đóng phiên sau lỗi này)


class LineTooLong(Exception):
    """Dòng nhận được dài hơn MAX_LINE."""


def err(code):
    """Tạo dòng báo lỗi: ERR|<mã>."""
    return f"ERR{SEP}{code}"


def send_line(sock, line):
    """Gửi một dòng; tự thêm "\\n" ở cuối và mã hóa UTF-8."""
    if "\n" in line:
        raise ValueError("Nội dung dòng không được chứa '\\n'")
    sock.sendall((line + "\n").encode(ENCODING))


def recv_line(sock, buf):
    """Đọc đúng MỘT dòng từ sock.

    buf là bytearray do người gọi giữ giữa các lần gọi: TCP là dòng byte,
    một lần recv() có thể chứa nhiều dòng hoặc chỉ một nửa dòng, phần dư
    được cất lại trong buf cho lần đọc sau.

    Trả về chuỗi đã bỏ "\\n" và "\\r" ở cuối (telnet/ncat trên Windows gửi
    "\\r\\n"), hoặc None nếu đối phương đã đóng kết nối.
    Ném LineTooLong nếu dòng dài hơn MAX_LINE.
    """
    while True:
        idx = buf.find(b"\n")
        if idx != -1:
            break
        if len(buf) > MAX_LINE:
            raise LineTooLong()
        chunk = sock.recv(MAX_LINE)
        if chunk == b"":          # đối phương đóng kết nối
            return None
        buf.extend(chunk)
    if idx > MAX_LINE:
        raise LineTooLong()
    raw = bytes(buf[:idx])
    del buf[:idx + 1]
    return raw.decode(ENCODING, errors="replace").rstrip("\r")

import struct

# ---- Cấu hình cho truyền tệp (Phần C) ----
PREFIX_STRUCT = struct.Struct("!I")  # Tiền tố độ dài 4 byte (Big-endian)
MAX_MSG = 50 * 1024 * 1024           # Kích thước tối đa của một thông điệp/tệp (ví dụ 50 MB)

def recv_exactly(sock, num_bytes):
    """Đọc chính xác num_bytes từ socket.
    
    Phục vụ cho việc đọc đúng số lượng byte của tiền tố và payload nhị phân.
    """
    data = bytearray()
    while len(data) < num_bytes:
        packet = sock.recv(num_bytes - len(data))
        if not packet:
            raise EOFError("Socket đã đóng trước khi nhận đủ dữ liệu.")
        data.extend(packet)
    return bytes(data)

def send_msg(sock, data: bytes):
    """Đóng khung dữ liệu bằng tiền tố độ dài 4 byte trước khi gửi."""
    if len(data) > MAX_MSG:
        raise ValueError(f"Kích thước dữ liệu quá lớn: {len(data)} byte.")
    
    # Gói độ dài thành 4 byte và ghép vào trước dữ liệu
    prefix = PREFIX_STRUCT.pack(len(data))
    sock.sendall(prefix + data)

def recv_msg(sock):
    """Nhận thông điệp nhị phân dựa trên tiền tố độ dài 4 byte."""
    # Bước 1: Đọc chính xác 4 byte tiền tố để biết kích thước
    prefix_bytes = recv_exactly(sock, PREFIX_STRUCT.size)
    msg_length = PREFIX_STRUCT.unpack(prefix_bytes)[0]
    
    if msg_length > MAX_MSG:
        raise ValueError(f"Thông điệp báo kích thước quá lớn: {msg_length} byte.")
    
    # Bước 2: Đọc chính xác phần dữ liệu dựa trên kích thước vừa giải mã
    return recv_exactly(sock, msg_length)