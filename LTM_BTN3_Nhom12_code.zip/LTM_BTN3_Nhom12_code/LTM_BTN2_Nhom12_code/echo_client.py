#Nhóm       : Nhom12
#Người viết : Trần Thanh Hằng 3120224047

#Cách chạy  : python echo_client.py

import socket
import sys

SERVER_IP = sys.argv[1] if len(sys.argv) > 1 else "127.0.0.1"
PORT = int(sys.argv[2]) if len(sys.argv) > 2 else 9012
BUFSIZE = 1024

VIET = "Xin chào, tôi là sinh viên Việt Nam – Đà Nẵng đẹp lắm!"
LONG = "Lập trình mạng " * 333          # ~5000 ký tự


def echo_once(c, text):
    payload = text.encode("utf-8")                    # mã hóa UTF-8
    print(f"len(text) = {len(text)} | len(text.encode('utf-8')) = {len(payload)}")
    c.sendall(payload)
    received, calls = b"", 0
    while len(received) < len(payload):               # gom đủ số byte đã gửi
        chunk = c.recv(BUFSIZE)
        if chunk == b"":                              # server đóng kết nối
            print("Server đã đóng kết nối.")
            return False
        received += chunk
        calls += 1
    back = received.decode("utf-8")                   # giải mã UTF-8 sau khi đủ byte
    print(f"Số lần recv() = {calls} (BUFSIZE={BUFSIZE}) | khớp: {back == text}")
    if len(back) <= 100:
        print("Echo:", back)
    return True


def main():
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as c:
            c.settimeout(5)                           # timeout phía client
            c.connect((SERVER_IP, PORT))
            print("Đã kết nối:", c.getsockname(), "->", c.getpeername())
            while True:
                text = input("Nhập chuỗi (rỗng = thoát): ")
                if text == "":
                    break
                if text == "/viet":
                    text = VIET
                elif text == "/long":
                    text = LONG
                if not echo_once(c, text):
                    break
    except ConnectionRefusedError as e:               # phải đặt TRƯỚC OSError
        print("Bị từ chối kết nối (server chưa chạy / sai IP, cổng):", e)
    except socket.timeout:
        print("Hết thời gian chờ (timeout).")
    except OSError as e:
        print("Lỗi mạng (OSError):", e)


if __name__ == "__main__":
    main()