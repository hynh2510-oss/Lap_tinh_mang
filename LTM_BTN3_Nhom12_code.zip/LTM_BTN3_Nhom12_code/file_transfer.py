import socket
import os
import hashlib
import argparse
import protocol  # Import module chứa send_msg, recv_msg

def calc_sha256(data: bytes) -> str:
    """Tính mã băm SHA-256 và trả về 8 ký tự đầu."""
    return hashlib.sha256(data).hexdigest()[:8]

def run_server(host, port):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as srv:
        srv.bind((host, port))
        srv.listen(1)
        print(f"[Server] Đang chờ tệp tại {host}:{port}...")
        
        conn, addr = srv.accept()
        with conn:
            print(f"[Server] Đã chấp nhận kết nối từ {addr}")
            
            raw_filename_bytes = protocol.recv_msg(conn)
            raw_filename = raw_filename_bytes.decode('utf-8')
            
            # Phía nhận bắt buộc gọi os.path.basename() trên tên tệp nhận được[cite: 1]
            safe_filename = os.path.basename(raw_filename) 
            save_path = f"nhan_{safe_filename}"
            
            print(f"[Server] Đang nhận tệp {safe_filename}...")
            file_data = protocol.recv_msg(conn)
            
            with open(save_path, "wb") as f:
                f.write(file_data)
                
            print(f"[Server] Đã lưu tệp vào: {save_path}")
            print(f"[Server] Kích thước nhận: {len(file_data)} byte")
            print(f"[Server] SHA-256 (bên nhận): {calc_sha256(file_data)}")

def run_client(host, port, filepath):
    if not os.path.exists(filepath):
        print(f"[Client] Lỗi: Không tìm thấy tệp '{filepath}'")
        return

    with open(filepath, "rb") as f:
        file_data = f.read()

    filename = os.path.basename(filepath)

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.connect((host, port))
        print(f"[Client] Đã kết nối tới {host}:{port}")
        
        protocol.send_msg(s, filename.encode('utf-8'))
        
        print(f"[Client] Đang gửi tệp {filename} ({len(file_data)} byte)...")
        protocol.send_msg(s, file_data)
        
        print(f"[Client] Gửi thành công.")
        print(f"[Client] SHA-256 (bên gửi): {calc_sha256(file_data)}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Chương trình truyền tệp qua TCP")
    parser.add_argument("mode", choices=["server", "client"], help="Chế độ hoạt động")
    parser.add_argument("--host", default="0.0.0.0", help="Địa chỉ IP (mặc định 0.0.0.0 cho server)")
    parser.add_argument("--port", type=int, default=9000, help="Cổng kết nối")
    parser.add_argument("--file", help="Đường dẫn tệp để gửi (bắt buộc với client)")

    args = parser.parse_args()

    if args.mode == "server":
        run_server(args.host, args.port)
    else:
        if not args.file:
            print("Lỗi: Khi chạy client, cần truyền tên tệp qua tham số --file")
        else:
            host = args.host if args.host != "0.0.0.0" else "127.0.0.1"
            run_client(host, args.port, args.file)