import socket
import time

# --- phia_nhan.py: bận 1 giây rồi mới đọc ---[cite: 1]
def main():
    HOST = '127.0.0.1'
    PORT = 9012  # Đổi thành cổng của nhóm bạn

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as srv:
        srv.bind((HOST, PORT))
        srv.listen(1)
        print(f"Phía nhận đang chờ ở {HOST}:{PORT}...")
        
        conn, addr = srv.accept() #[cite: 1]
        with conn:
            print(f"Đã kết nối từ {addr}")
            
            time.sleep(1) #[cite: 1]
            dau = conn.recv(60) # (1) đọc tối đa 60 byte[cite: 1]
            print(f"60 byte đầu tiên đọc được:\n{dau}") # ba tin có dính nhau?[cite: 1]
            
            tong, lan = len(dau), 1 #[cite: 1]
            while True:
                chunk = conn.recv(65536) #[cite: 1]
                if not chunk: # bên gửi đã đóng[cite: 1]
                    break #[cite: 1]
                tong += len(chunk) #[cite: 1]
                lan += 1 #[cite: 1]
                
            print(tong, "byte /", lan, "lần recv()") # (2) tách gói[cite: 1]

if __name__ == "__main__":
    main()