import socket, ipaddress
 
domain = "ued.udn.vn"     
print(domain, "->", socket.gethostbyname(domain))
 
iface = ipaddress.ip_interface("192.168.10.1/24") 
net = iface.network
print("Mạng:", net.network_address)
print("Broadcast:", net.broadcast_address)
print("Số host:", net.num_addresses - 2)
