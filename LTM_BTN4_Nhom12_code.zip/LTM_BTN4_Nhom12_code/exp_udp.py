"""
exp_udp.py - Nhóm 12 - Bài thực hành 4, Phần C
Thành viên viết: <điền tên>

Hai thí nghiệm lỗi kinh điển của UDP, chỉ chạy trên 127.0.0.1 (gửi dồn hàng nghìn datagram).

Thí nghiệm 1 - MẤT GÓI và gửi lại (lỗi ①). Chạy 3 lần, mỗi lần một p (khởi động lại server):
    python udp_chat_server.py --port 9012 --loss 0.1
    python exp_udp.py loss --port 9012 --p 0.1
    (lặp lại với 0.3 và 0.5)

Thí nghiệm 2 - LẶP GÓI và mã yêu cầu (lỗi ②). Server phải chạy với --reply-loss:
    python udp_chat_server.py --port 9012 --reply-loss 0.3
    python exp_udp.py dup --port 9012            (3 lần, KHÔNG gắn mã)
    python exp_udp.py dup --port 9012 --rid      (3 lần, CÓ gắn mã)

Nguồn: ask() trong protocol.py (khung slide Chương 4 mục 4.3, exp_ask.py).
Nhóm tự viết: đếm số lần gửi, so với lý thuyết, hai socket A/B, in sẵn dòng cho Bảng 3 và Bảng 4.
"""
import argparse
import random
import socket
import sys
import time

from protocol import ask, recv_dgram


def vn(x, nd=1):
    """Số thực -> chuỗi dùng dấu phẩy thập phân, như trong báo cáo."""
    return f"{x:.{nd}f}".replace(".", ",")


def new_sock(args):
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.connect((args.host, args.port))
    return s


def check_server(args):
    """Báo lỗi tiếng Việt nếu server chưa chạy."""
    s = new_sock(args)
    try:
        ask(s, "PING|0", "PONG|0", timeout=0.1, tries=6)
    except TimeoutError:
        raise SystemExit("Server không trả lời PING. Đã chạy udp_chat_server.py chưa, đúng --port chưa?")
    except (ConnectionRefusedError, ConnectionResetError):
        raise SystemExit("Cổng đóng: chưa có server nào chạy ở địa chỉ/cổng này.")
    finally:
        s.close()


# ====================================================================== LOSS
def run_loss(args):
    n, p, tries = args.n, args.p, args.tries
    s = new_sock(args)
    done = [0] * (tries + 1)          # done[k] = số yêu cầu xong ở lần gửi thứ k
    fail = 0

    t0 = time.monotonic()
    for i in range(n):
        info = {}
        try:
            ask(s, f"PING|{i}", f"PONG|{i}", timeout=args.timeout, tries=tries, info=info)
            done[info["sent"]] += 1
        except TimeoutError:
            fail += 1
    dt = time.monotonic() - t0
    s.close()

    theory = [n * (1 - p) * p ** (k - 1) for k in range(1, tries + 1)]
    theory_fail = n * p ** tries

    print(f"N = {n}, p (server --loss) = {p}, thời gian chờ đầu = {args.timeout} s, "
          f"tối đa {tries} lần gửi, chạy {dt:.1f} s\n")
    print(f"{'':16}{'đo được':>10}{'lý thuyết':>12}")
    for k in range(1, tries + 1):
        print(f"xong sau {k} lần {done[k]:>10}{theory[k - 1]:>12.1f}")
    print(f"thất bại      {fail:>10}{theory_fail:>12.1f}")
    print(f"(kiểm tra: {sum(done)} xong + {fail} thất bại = {sum(done) + fail} / {n})")

    # Phát hiện quên khởi động lại server với --loss đúng
    p_hat = 1 - done[1] / n
    if abs(p_hat - p) > 0.06:
        print(f"\n!! Ước lượng p từ dữ liệu = {p_hat:.2f}, lệch xa --p {p}. "
              f"Server có đang chạy --loss {p} không?")

    cells = [f"{done[k]} / {vn(theory[k - 1])}" for k in range(1, tries + 1)]
    cells.append(f"{fail} / {vn(theory_fail)}")
    print("\nDòng cho Bảng 3 (đo được / lý thuyết):")
    print(f"| {vn(p)} | " + " | ".join(cells) + " |")


# ======================================================================= DUP
def login(s, name):
    r = ask(s, f"LOGIN|{name}", ("OK|", "ERR|"), timeout=0.1, tries=8)
    if not r.startswith("OK|"):
        raise SystemExit(f"LOGIN|{name} bị từ chối: {r}")


def leave(s):
    try:
        ask(s, "QUIT", "BYE", timeout=0.05, tries=8)
    except OSError:
        pass
    s.close()


def dup_once(args):
    tok = f"{random.randrange(16 ** 4):04x}"
    sa, sb = new_sock(args), new_sock(args)
    login(sa, f"A{tok}")
    login(sb, f"B{tok}")

    resends = fails = 0
    for i in range(1, args.n + 1):
        info = {}
        try:
            r = ask(sa, f"MSG|all|tin {i} {tok}", ("OK|", "ERR|"),
                    timeout=args.timeout, tries=args.tries,
                    rid=i if args.rid else None, info=info)
            if r.startswith("ERR|"):
                raise SystemExit(f"Server trả lỗi cho tin {i}: {r}")
        except TimeoutError:
            fails += 1
        resends += info["sent"] - 1

    # B đọc hết những gì đã nằm trong bộ đệm, dừng khi im lặng args.quiet giây
    got = []
    sb.settimeout(args.quiet)
    while True:
        try:
            text, _ = recv_dgram(sb)
        except socket.timeout:
            break
        except ValueError:
            continue
        if text.startswith("FROM|") and text.endswith(tok):
            got.append(text.split("|", 3)[3])

    leave(sa)
    leave(sb)
    return resends, fails, len(got), len(got) - len(set(got))


def run_dup(args):
    mode = "CÓ mã yêu cầu" if args.rid else "KHÔNG mã yêu cầu"
    print(f"A gửi {args.n} tin cả phòng, thời gian chờ đầu {args.timeout} s, "
          f"tối đa {args.tries} lần gửi, {mode}. Server phải chạy --reply-loss 0.3\n")

    runs = []
    for k in range(1, args.repeat + 1):
        r = dup_once(args)
        runs.append(r)
        print(f"[lần {k}] A gửi lại {r[0]:>3} | A báo thất bại {r[1]:>2} | "
              f"B nhận {r[2]:>3} tin FROM | lặp ở B {r[3]:>3}")

    print("\nDòng cho Bảng 4 (ba lần chạy):")
    cols = [" / ".join(str(r[c]) for r in runs) for c in range(4)]
    print(f"| {'Có' if args.rid else 'Không'} | " + " | ".join(cols) + " |")


# ======================================================================= main
def main():
    ap = argparse.ArgumentParser(description="Thí nghiệm UDP: mất gói (loss) và lặp gói (dup)")
    common = argparse.ArgumentParser(add_help=False)      # --host/--port đứng được SAU tên thí nghiệm
    common.add_argument("--host", default="127.0.0.1")
    common.add_argument("--port", type=int, default=9012)
    sub = ap.add_subparsers(dest="mode", required=True)

    pl = sub.add_parser("loss", parents=[common], help="mất gói và gửi lại (Bảng 3)")
    pl.add_argument("--p", type=float, required=True, help="xác suất mất của server (--loss), dùng tính lý thuyết")
    pl.add_argument("--n", type=int, default=1000, help="số yêu cầu")
    pl.add_argument("--timeout", type=float, default=0.02, help="thời gian chờ đầu (giây)")
    pl.add_argument("--tries", type=int, default=4, help="số lần gửi tối đa")
    pl.set_defaults(fn=run_loss)

    pd = sub.add_parser("dup", parents=[common], help="lặp gói và mã yêu cầu (Bảng 4)")
    pd.add_argument("--rid", action="store_true", help="gắn mã yêu cầu tăng dần")
    pd.add_argument("--n", type=int, default=100, help="số tin A gửi")
    pd.add_argument("--repeat", type=int, default=3, help="số lần chạy liền nhau")
    pd.add_argument("--timeout", type=float, default=0.1, help="thời gian chờ đầu (giây)")
    pd.add_argument("--tries", type=int, default=4, help="số lần gửi tối đa")
    pd.add_argument("--quiet", type=float, default=1.0, help="B chờ im lặng bao lâu thì coi là hết tin")
    pd.set_defaults(fn=run_dup)

    args = ap.parse_args()
    if args.host != "127.0.0.1":
        print("Cảnh báo: thí nghiệm này gửi dồn nhiều datagram, chỉ nên chạy trên 127.0.0.1.", file=sys.stderr)

    check_server(args)
    args.fn(args)


if __name__ == "__main__":
    main()