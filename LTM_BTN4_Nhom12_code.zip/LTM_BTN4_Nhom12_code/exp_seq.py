
import socket

r = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
r.bind(("127.0.0.1", 0))
r.settimeout(0.5)

s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

# Giả lập: gói 3 đến muộn, gói 4 bị lặp, gói 5 bị thiếu
for n in [1, 2, 4, 3, 4, 6]:
    s.sendto(f"{n}|dữ liệu".encode(), r.getsockname())

last, seen = 0, set()

try:
    while True:
        data, addr = r.recvfrom(1500)
        n = int(data.split(b"|")[0])

        if n in seen:
            print(f"#{n}: LẶP -> bỏ qua")
            continue

        seen.add(n)

        if n < last:
            print(f"#{n}: đến MUỘN (đã nhận đến #{last})")
        elif n > last + 1:
            print(f"#{n}: NHẢY CÓC, thiếu {n - last - 1} gói")
        else:
            print(f"#{n}: đúng thứ tự")

        last = max(last, n)

except socket.timeout:
    missing = sorted(set(range(1, last + 1)) - seen)
    print("Gói bị thiếu:", missing)

finally:
    r.close()
    s.close()
