"""
Nhom 12

Server UDP cho ung dung chat 2TEN

Lenh chay:

python udp_chat_server.py

python udp_chat_server.py --port 9012

python udp_chat_server.py --port 9012 --loss 0.3

python udp_chat_server.py --port 9012 --reply-loss 0.3
"""

import argparse
import logging
import random
import socket
import time

from protocol import send_dgram
from protocol import recv_dgram


ROOM = "2TEN_CHAT"

MAX_TEXT = 1000
IDLE = 60

RESERVED = {
    "all",
    "server"
}

clients = {}


def names():
    return {
        c["name"]
        for c in clients.values()
    }


def to_room(text, skip=None):
    result = []

    for addr in clients:

        if addr != skip:
            result.append(
                (text, addr)
            )

    return result


def do_login(name, addr):

    if addr in clients:

        if clients[addr]["name"] == name:

            return [
                (
                    f"OK|Chao {name}",
                    addr
                )
            ]

        return [
            (
                "ERR|3|Da dang nhap",
                addr
            )
        ]

    ok = (
        0 < len(name) <= 20
        and "|" not in name
        and name.isprintable()
    )

    if not ok:

        return [
            (
                "ERR|2|Ten khong hop le",
                addr
            )
        ]

    if (
        name.lower() in RESERVED
        or name.lower() in {n.lower() for n in names()}
    ):

        return [
            (
                "ERR|1|Ten da ton tai",
                addr
            )
        ]

    out = to_room(
        f"SYS|{name} vao phong"
    )

    clients[addr] = {
        "name": name,
        "seen": time.monotonic()
    }

    return [
        (
            f"OK|Chao {name}",
            addr
        )
    ] + out


def do_msg(arg, sess, addr):

    receiver, sep, text = arg.partition("|")

    if not sep or not text:

        return [
            (
                "ERR|4|Sai cu phap",
                addr
            )
        ]

    if (
        len(text.encode("utf-8"))
        > MAX_TEXT
    ):

        return [
            (
                "ERR|4|Noi dung qua 1000 byte",
                addr
            )
        ]

    push = (
        f"FROM|{sess['name']}|"
        f"{receiver}|{text}"
    )

    if receiver == "all":

        return [
            (
                "OK|Da gui",
                addr
            )
        ] + to_room(
            push,
            skip=addr
        )

    for a, c in clients.items():

        if c["name"] == receiver:

            return [
                (
                    "OK|Da gui",
                    addr
                ),
                (
                    push,
                    a
                )
            ]

    return [
        (
            "ERR|5|Nguoi nhan khong ton tai",
            addr
        )
    ]


def do_quit(addr):

    sess = clients.pop(
        addr,
        None
    )

    out = [
        (
            "BYE",
            addr
        )
    ]

    if sess:

        out += to_room(
            f"SYS|{sess['name']} roi phong"
        )

    return out


def handle_datagram(text, addr):

    cmd, _, arg = text.partition("|")

    sess = clients.get(addr)

    if sess:
        sess["seen"] = time.monotonic()

    if cmd == "DISCOVER":

        return [
            (
                f"HERE|{ROOM}|{len(clients)}",
                addr
            )
        ]

    if cmd == "PING":

        return [
            (
                f"PONG|{arg}",
                addr
            )
        ]

    if cmd == "LOGIN":
        return do_login(arg, addr)

    if cmd == "QUIT":
        return do_quit(addr)

    if sess is None:

        return [
            (
                "ERR|3|Chua dang nhap",
                addr
            )
        ]

    if cmd == "WHO":

        ds = ",".join(
            sorted(names())
        )

        return [
            (
                f"WHO|{ds}",
                addr
            )
        ]

    if cmd == "MSG":

        return do_msg(
            arg,
            sess,
            addr
        )

    return [
        (
            "ERR|4|Lenh khong hop le",
            addr
        )
    ]


# ---- Phan C: ma yeu cau (rid) chong lap goi --------------------------
# last_reply[addr] = (rid, tra loi da gui). Gap lai rid cu thi chi gui lai
# tra loi cu, KHONG xu ly lenh lan nua.
last_reply = {}


def split_rid(text):
    """'7|MSG|all|hi' -> (7, 'MSG|all|hi'); 'MSG|all|hi' -> (None, text)."""
    head, sep, rest = text.partition("|")

    if sep and head.isascii() and head.isdigit() and len(head) <= 9:
        return int(head), rest

    return None, text


def handle_with_rid(text, addr):

    rid, body = split_rid(text)

    if rid is None:
        return handle_datagram(text, addr)

    old = last_reply.get(addr)

    if old and old[0] == rid:

        sess = clients.get(addr)

        if sess:
            sess["seen"] = time.monotonic()

        logging.info(
            "%s:%d ma %d lap lai -> gui lai tra loi cu",
            *addr,
            rid
        )

        return [
            (
                old[1],
                addr
            )
        ]

    out = handle_datagram(body, addr)

    out[0] = (
        f"{rid}|{out[0][0]}",
        out[0][1]
    )

    last_reply[addr] = (
        rid,
        out[0][0]
    )

    return out


def deliver(sock, out):

    for text, addr in out:

        try:

            send_dgram(
                sock,
                text,
                addr
            )

        except (
            OSError,
            ValueError
        ) as e:

            logging.warning(
                "Loi gui %s:%d : %s",
                *addr,
                e
            )


def reap_idle(sock):

    now = time.monotonic()

    remove_list = []

    for addr, c in clients.items():

        if now - c["seen"] > IDLE:

            remove_list.append(
                (
                    addr,
                    c["name"]
                )
            )

    for addr, name in remove_list:

        del clients[addr]
        last_reply.pop(addr, None)

        logging.info(
            "%s mat lien lac",
            name
        )

        deliver(
            sock,
            to_room(
                f"SYS|{name} mat lien lac"
            )
        )


def create_socket(host, port):

    sock = socket.socket(
        socket.AF_INET,
        socket.SOCK_DGRAM
    )

    sock.bind(
        (host, port)
    )

    return sock


def serve_forever(
    sock,
    loss=0.0,
    reply_loss=0.0
):

    sock.settimeout(1.0)

    while True:

        try:

            text, addr = recv_dgram(sock)

        except socket.timeout:

            reap_idle(sock)
            continue

        except (
            OSError,
            ValueError
        ) as e:

            logging.warning(
                "Bo qua datagram: %s",
                e
            )

            continue

        if random.random() < loss:

            logging.info(
                "%s:%d >> %s [MAT]",
                *addr,
                text
            )

            continue

        logging.info(
            "%s:%d >> %s",
            *addr,
            text
        )

        out = handle_with_rid(
            text,
            addr
        )

        if (
            out
            and random.random()
            < reply_loss
        ):

            logging.info(
                "%s:%d << %s [MAT TRA LOI]",
                *addr,
                out[0][0]
            )

            out = out[1:]

        deliver(sock, out)

        reap_idle(sock)


def main():

    parser = argparse.ArgumentParser(
        description="UDP Chat Server"
    )

    parser.add_argument(
        "--host",
        default="0.0.0.0"
    )

    parser.add_argument(
        "--port",
        type=int,
        default=9012
    )

    parser.add_argument(
        "--idle",
        type=int,
        default=60
    )

    parser.add_argument(
        "--loss",
        type=float,
        default=0.0
    )

    parser.add_argument(
        "--reply-loss",
        type=float,
        default=0.0
    )

    args = parser.parse_args()

    global IDLE
    IDLE = args.idle

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(message)s"
    )

    try:

        sock = create_socket(
            args.host,
            args.port
        )

    except OSError as e:

        raise SystemExit(
            f"Khong mo duoc cong: {e}"
        )

    logging.info(
        "UDP SERVER %s:%d",
        args.host,
        args.port
    )

    with sock:

        try:

            serve_forever(
                sock,
                args.loss,
                args.reply_loss
            )

        except KeyboardInterrupt:

            logging.info(
                "Dung server"
            )   
if __name__ == "__main__":
    main()