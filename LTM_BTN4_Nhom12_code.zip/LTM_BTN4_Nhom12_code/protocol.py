"""
Nhom 12

File: protocol.py

Chua cac ham gui/nhan UDP dung chung
cho server va client.

Cach dung:
from protocol import send_dgram, recv_dgram, ask

Nguon: send_dgram(), recv_dgram() theo khung slide Chuong 4 (nhom da viet).
Nhom tu viet them: ask() - hen gio, gui lai, ma yeu cau (rid), dem so lan gui (info).
"""

import socket
import time

MAX_DGRAM = 1200

def send_dgram(sock, text, addr=None):
    data = (text + "\n").encode("utf-8")

    if len(data) > MAX_DGRAM:
        raise ValueError(
            f"Datagram {len(data)} byte qua lon"
        )

    if addr is None:
        sock.send(data)
    else:
        sock.sendto(data, addr)


def recv_dgram(sock):
    """
    Tra ve:
        (text, addr)

    Nhan MAX_DGRAM + 1 de phat hien bi cat.
    """

    data, addr = sock.recvfrom(MAX_DGRAM + 1)

    if len(data) > MAX_DGRAM:
        raise ValueError(
            f"Datagram qua lon tu {addr}"
        )

    try:
        text = data.decode("utf-8").rstrip("\r\n")

    except UnicodeDecodeError:
        raise ValueError(
            "UTF-8 khong hop le"
        )

    return text, addr


def ask(sock, text, match, timeout=0.5, tries=4, rid=None, info=None):
    """
    Gui `text` roi cho tra loi KHOP YEU CAU; mat thi gui lai.

    sock    : socket UDP da connect() toi server.
    match   : tien to cua tra loi can nhan - mot chuoi ("BYE")
              hoac nhieu chuoi (("OK|", "ERR|")).
    timeout : thoi gian cho lan gui dau (giay); moi lan gui lai cho GAP DOI.
              Mac dinh 0.5 giay, toi da 4 lan gui => cho 0.5+1+2+4 = 7.5 giay.
    tries   : so lan gui toi da.
    rid     : (Phan C) ma yeu cau. Neu co, dong gui di la "<rid>|<text>",
              chi nhan tra loi bat dau bang "<rid>|" (da cat ma truoc khi
              tra ve), nen tra loi cu den tre khong bi nhan nham.
    info    : (Phan C) dict rong de ask() ghi vao info["sent"] = so lan da gui
              (dung dem "xong sau k lan gui" trong exp_udp.py).

    Tra ve : chuoi tra loi (khong con ma rid).
    Nem    : TimeoutError neu het `tries` lan van khong co tra loi khop.
             ConnectionRefusedError / ConnectionResetError neu cong dong.
    """
    prefixes = (match,) if isinstance(match, str) else tuple(match)
    tag = "" if rid is None else f"{rid}|"
    wire = tag + text
    wait = timeout

    if info is not None:
        info["sent"] = 0

    for _ in range(tries):
        send_dgram(sock, wire)
        if info is not None:
            info["sent"] += 1

        end = time.monotonic() + wait
        while (left := end - time.monotonic()) > 0:
            sock.settimeout(left)
            try:
                reply, _ = recv_dgram(sock)
            except socket.timeout:
                break                      # het gio lan nay -> gui lai
            except ValueError:
                continue                   # datagram hong: bo qua, van cho tiep
            if tag:
                if not reply.startswith(tag):
                    continue               # tra loi cua yeu cau khac
                reply = reply[len(tag):]
            if reply.startswith(prefixes):
                return reply
            # khong khop (vi du tin FROM/SYS day toi): bo qua, cho tiep

        wait *= 2

    raise TimeoutError(
        f"Khong nhan duoc tra loi sau {tries} lan gui: {text[:30]!r}"
    )