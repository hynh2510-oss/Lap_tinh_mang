"""
udp_chat_client.py - Nhóm 12 - Bài thực hành 4, Phần B
Thành viên viết: <điền tên>
Chạy:  python udp_chat_client.py --port 9012            (server cùng máy)
       python udp_chat_client.py --host 192.168.1.5 --port 9012
       python udp_chat_client.py --find --port 9012     (tìm server bằng broadcast)
Nguồn: khung client theo slide Chương 4 mục 4.3 (socket connect(), ask()).
Nhóm tự viết thêm: luồng nhận nền + PING, --find, xử lý lệnh @tên /who /quit,
báo lỗi tiếng Việt, tự QUIT khi thoát.
"""
import argparse
import socket
import threading
import time

from protocol import ask, recv_dgram, send_dgram

DEFAULT_PORT = 9012          # 9000 + mã nhóm 12
PING_EVERY = 20              # giây

ERR_TEXT = {
    "1": "Tên đã có người dùng (không phân biệt hoa/thường, 'all' và 'server' là tên dành riêng).",
    "2": "Tên không hợp lệ (1-20 ký tự, không chứa '|', không ký tự điều khiển, không khoảng trắng đầu/cuối).",
    "3": "Sai trình tự (chưa đăng nhập hoặc đã đăng nhập bằng tên khác).",
    "4": "Sai cú pháp hoặc nội dung rỗng / quá 1000 byte.",
    "5": "Người nhận không có trong phòng.",
    "6": "Phòng đã đầy.",
}


# ---------------------------------------------------------------- tìm server
def find_server(port, bcast="<broadcast>", wait=2.0):
    """Gửi DISCOVER bằng broadcast, gom mọi HERE|... trong `wait` giây."""
    found, seen = [], set()
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
    with s:
        t0 = time.monotonic()
        sent = 0
        while time.monotonic() - t0 < wait:
            if sent < 2 and time.monotonic() - t0 >= sent * 1.0:   # gửi lúc 0 s và 1 s (phòng mất gói)
                send_dgram(s, "DISCOVER", (bcast, port))
                sent += 1
            s.settimeout(0.2)
            try:
                text, addr = recv_dgram(s)
            except (socket.timeout, ValueError, ConnectionResetError):
                continue
            cmd, _, arg = text.partition("|")
            if cmd == "HERE" and addr not in seen:
                seen.add(addr)
                room, _, count = arg.partition("|")
                found.append((addr[0], addr[1], room, count))
    return found


# ------------------------------------------------------------- luồng nhận nền
def show_incoming(text):
    cmd, _, rest = text.partition("|")
    if cmd == "FROM":
        who, _, rest = rest.partition("|")
        to, _, content = rest.partition("|")
        if to.lower() == "all":
            print(f"[{who}] {content}", flush=True)
        else:
            print(f"[{who} -> bạn, riêng] {content}", flush=True)
    elif cmd == "SYS":
        print(f"* {rest}", flush=True)
    elif cmd == "WHO":
        print(f"Đang trong phòng: {rest}", flush=True)
    elif cmd == "ERR":
        code = rest.partition("|")[0]
        print(f"! Lỗi {code}: {ERR_TEXT.get(code, rest)}", flush=True)
    # OK / PONG / BYE: không in


def receiver(sock, stop, lost, ping_every):
    """Nơi DUY NHẤT đọc socket sau khi đăng nhập; cũng gửi PING định kỳ."""
    sock.settimeout(1.0)
    seq = 0
    next_ping = time.monotonic() + ping_every
    while not stop.is_set():
        if time.monotonic() >= next_ping:
            seq += 1
            try:
                send_dgram(sock, f"PING|{seq}")
            except OSError:
                pass
            next_ping += ping_every
        try:
            text, _ = recv_dgram(sock)
        except socket.timeout:
            continue
        except ValueError:
            continue                              # datagram hỏng: bỏ qua
        except (ConnectionRefusedError, ConnectionResetError):
            print("\n! Server không còn phản hồi (đã dừng?). Nhấn Enter để thoát.", flush=True)
            lost.set()
            stop.set()
            return
        except OSError:
            return
        show_incoming(text)


# ------------------------------------------------------------------ đăng nhập
def login(sock):
    while True:
        name = input("Tên của bạn: ")
        if name == "":
            continue
        reply = ask(sock, f"LOGIN|{name}", ("OK|", "ERR|"))   # 0,5 s, gửi tối đa 4 lần, gấp đôi mỗi lần
        if reply.startswith("OK"):
            return name
        code = reply.split("|")[1] if "|" in reply else "?"
        print(f"! Lỗi {code}: {ERR_TEXT.get(code, reply)}")
        if code == "6":
            raise SystemExit("Phòng đã đầy, thử lại sau.")


# ------------------------------------------------------------- vòng đọc bàn phím
def chat_loop(sock, stop):
    print("Gõ nội dung để gửi cả phòng | @tên nội dung: gửi riêng | /who | /quit")
    while not stop.is_set():
        try:
            line = input()
        except (EOFError, KeyboardInterrupt):
            print("\nĐang thoát (Ctrl+C / Ctrl+D)...")
            return
        if stop.is_set():
            return
        if not line.strip():
            continue
        if line == "/quit":
            return
        if line == "/who":
            cmd = "WHO"
        elif line.startswith("@"):
            to, _, content = line[1:].partition(" ")
            if not to or not content.strip():
                print("Cú pháp gửi riêng: @tên nội dung")
                continue
            cmd = f"MSG|{to}|{content}"
        else:
            cmd = f"MSG|all|{line}"
        try:
            send_dgram(sock, cmd)
        except ValueError:
            print("! Tin quá dài (datagram vượt 1200 byte), hãy gõ ngắn lại.")
        except OSError as e:
            print(f"! Không gửi được: {e}")
            return


def leave(sock, stop, thread):
    """Mọi đường thoát đều gửi QUIT (có chờ BYE, gửi lại nếu mất)."""
    stop.set()
    thread.join(timeout=2)
    try:
        ask(sock, "QUIT", "BYE", timeout=0.3, tries=3)
        print("Đã rời phòng.")
    except OSError:
        print("Đã gửi QUIT nhưng không nhận được BYE; server sẽ tự xóa sau thời gian --idle.")


# ------------------------------------------------------------------------ main
def main():
    ap = argparse.ArgumentParser(description="UDP Chat Client")
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=DEFAULT_PORT)
    ap.add_argument("--find", action="store_true", help="tìm server bằng broadcast")
    ap.add_argument("--bcast", default="<broadcast>",
                    help="địa chỉ broadcast (mặc định <broadcast>; nếu nhiều card mạng, dùng vd 192.168.1.255)")
    ap.add_argument("--ping", type=float, default=PING_EVERY, help="chu kỳ PING (giây)")
    args = ap.parse_args()

    sock = None
    try:
        if args.find:
            servers = find_server(args.port, args.bcast)
            if not servers:
                print("Không tìm thấy server nào trong 2 giây (mạng có thể chặn broadcast).")
                return
            for ip, port, room, count in servers:
                print(f"Tìm thấy server {ip}:{port} - phòng '{room}' - {count} người")
            args.host, args.port = servers[0][0], servers[0][1]
            print(f"Kết nối tới server đầu tiên: {args.host}:{args.port}")

        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.connect((args.host, args.port))      # UDP connect(): chỉ gán địa chỉ đích, không bắt tay

        name = login(sock)
        print(f"Đã vào phòng với tên '{name}'.")

        stop, lost = threading.Event(), threading.Event()
        th = threading.Thread(target=receiver, args=(sock, stop, lost, args.ping), daemon=True)
        th.start()
        try:
            chat_loop(sock, stop)
        finally:
            leave(sock, stop, th)

    except TimeoutError:
        print("Server không trả lời sau 4 lần gửi (khoảng 7,5 giây). "
              "Hãy kiểm tra server đã chạy chưa và địa chỉ / cổng có đúng không.")
    except (ConnectionRefusedError, ConnectionResetError):
        print("Không kết nối được: không có server nào đang nghe ở địa chỉ và cổng này.")
    except (EOFError, KeyboardInterrupt):
        print("\nBạn đã hủy khi đang đăng nhập (Ctrl+C / Ctrl+D), chưa vào phòng nên không cần QUIT.")
    except OSError as e:
        print(f"Lỗi mạng: {e}")
    finally:
        if sock:
            sock.close()


if __name__ == "__main__":
    main()
