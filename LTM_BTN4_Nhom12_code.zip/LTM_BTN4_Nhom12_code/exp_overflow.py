"""
exp_overflow.py - Nhóm 12 - Bài thực hành 4, Phần C (lỗi ⑥: tràn bộ đệm nhận)
Thành viên viết: <điền tên>
Chạy (chỉ trên 127.0.0.1, không cần server):
    python exp_overflow.py
Cách làm: socket nhận bind() nhưng CHƯA gọi recvfrom(); socket gửi bắn dồn 20 000
datagram; sau đó mới đọc hết và đếm. Hai lần thử: bộ đệm mặc định và xin 4 MB.
Nguồn: lấy từ slide Chương 4 mục 4.4 (slide 54, exp_overflow.py).
Nhóm tự thêm: in tên hệ điều hành và SO_RCVBUF mặc định để ghi vào báo cáo.
"""
import platform
import socket


def trial(rcvbuf=None, n=20_000):
    r = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    if rcvbuf:
        r.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, rcvbuf)
    r.bind(("127.0.0.1", 0))
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    for i in range(n):              # sendto() không hề báo lỗi
        s.sendto(i.to_bytes(4, "big") + bytes(96), r.getsockname())
    r.settimeout(0.3)
    got = 0
    try:
        while True:
            r.recvfrom(2048)
            got += 1
    except TimeoutError:
        pass
    size = r.getsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF)
    lost = 1 - got / n
    print(f"SO_RCVBUF = {size:>7}: nhận {got:>5}/{n}, mất {lost:.0%}")


print("Hệ điều hành:", platform.platform())
trial()                             # bộ đệm mặc định
trial(4 * 1024 * 1024)              # xin 4 MB