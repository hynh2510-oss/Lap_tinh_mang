"""
test_udp_server.py - Nhóm 12 - Bài thực hành 4, Phần B
Thành viên viết: <điền tên>
Chạy:  python test_udp_server.py --port 9012               (server chạy bình thường)
       python test_udp_server.py --port 9012 --repeat 3     (3 lần liền, in sẵn bảng cho Bảng 2)
Server cần chạy trước: python udp_chat_server.py --port 9012 [--loss 0.3]
Nguồn: dùng ask() trong protocol.py (khung slide Chương 4 mục 4.3).
Nhóm tự viết: các ca kiểm thử, cách tạo tên không trùng giữa các lần chạy, in bảng kết quả.
Mỗi ca dùng ask() (hẹn giờ + gửi lại) nên vẫn đúng khi server chạy --loss 0.3.
"""
import argparse
import random
import socket
import sys
import time

from protocol import ask, send_dgram, recv_dgram

HOST, PORT, T0, TRIES = "127.0.0.1", 9012, 0.2, 6
QUIET = 0.6          # giây chờ để khẳng định "server không trả lời"


class Client:
    def __init__(self):
        self.s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.s.connect((HOST, PORT))

    def ask(self, text, match):
        return ask(self.s, text, match, timeout=T0, tries=TRIES)

    def login(self, name):
        r = self.ask(f"LOGIN|{name}", ("OK|", "ERR|"))
        if not r.startswith("OK|"):
            raise AssertionError(f"LOGIN|{name} bị từ chối: {r}")

    def send(self, text):
        send_dgram(self.s, text)

    def wait(self, pred, timeout=2.0):
        """Chờ một datagram thỏa pred; trả về None nếu hết giờ."""
        end = time.monotonic() + timeout
        while (left := end - time.monotonic()) > 0:
            self.s.settimeout(left)
            try:
                text, _ = recv_dgram(self.s)
            except (socket.timeout, ValueError):
                continue
            if pred(text):
                return text
        return None

    def close(self):
        try:
            ask(self.s, "QUIT", "BYE", timeout=0.1, tries=8)
        except OSError:
            pass
        self.s.close()


class Env:
    """Tên không trùng giữa các lần chạy + dọn dẹp sau mỗi ca."""
    def __init__(self):
        self.tok = f"{random.randrange(16 ** 4):04x}"
        self.n = 0                      # số thứ tự ca: mỗi ca dùng tên riêng,
        self.clients, self.shared = [], {}   # phiên kẹt (QUIT bị mất) của ca trước không ảnh hưởng ca sau

    def name(self, tag):
        return f"{tag}{self.tok}{self.n}"

    def client(self, login=None):
        c = Client()
        self.clients.append(c)
        if login:
            c.login(login)
        return c

    def cleanup(self):
        for c in self.clients:
            c.close()
        self.clients = []


def check(cond, msg):
    if not cond:
        raise AssertionError(msg)


# ------------------------------------------------------------------ các ca
def t_sai_trinh_tu(e):
    c = e.client()
    r = c.ask("MSG|all|chào", "ERR|")
    check(r.startswith("ERR|3"), f"nhận {r!r}, cần ERR|3")

def t_login_ok(e):
    c = e.client()
    r = c.ask(f"LOGIN|{e.name('a')}", ("OK|", "ERR|"))
    check(r.startswith("OK|"), f"nhận {r!r}, cần OK|...")

def t_login_lai(e):
    n = e.name("a")
    c = e.client(login=n)
    r = c.ask(f"LOGIN|{n}", ("OK|", "ERR|"))             # lần 2, cùng địa chỉ, cùng tên
    check(r.startswith("OK|"), f"LOGIN lần 2 nhận {r!r}, cần OK|...")
    who = c.ask("WHO", ("WHO|", "ERR|"))
    names = [x.lower() for x in who.partition("|")[2].split(",")]
    check(names.count(n.lower()) == 1, f"tên xuất hiện {names.count(n.lower())} lần trong {who!r}")

def t_ten_trung(e):
    n = e.name("a")
    e.client(login=n)
    r = e.client().ask(f"LOGIN|{n.upper()}", ("OK|", "ERR|"))   # khác hoa/thường, địa chỉ khác
    check(r.startswith("ERR|1"), f"nhận {r!r}, cần ERR|1")

def t_ten_dai(e):
    r = e.client().ask("LOGIN|" + "x" * 21, ("OK|", "ERR|"))
    check(r.startswith("ERR|2"), f"nhận {r!r}, cần ERR|2")

def t_who(e):
    n = e.name("a")
    c = e.client(login=n)
    r = c.ask("WHO", ("WHO|", "ERR|"))
    check(r.startswith("WHO|") and n.lower() in r.lower(), f"nhận {r!r}, cần WHO|... có {n}")

def t_ping(e):
    r = e.client().ask("PING|7", ("PONG|", "ERR|"))
    check(r == "PONG|7", f"nhận {r!r}, cần PONG|7")

def t_msg_chung(e):
    a, b = e.name("a"), e.name("b")
    ca, cb = e.client(login=a), e.client(login=b)
    r = ca.ask("MSG|all|xin chào cả phòng", ("OK|", "ERR|"))
    check(r.startswith("OK|"), f"A nhận {r!r}, cần OK|...")
    got = cb.wait(lambda t: t.startswith("FROM|") and "xin chào cả phòng" in t)
    check(got is not None, "B không nhận được FROM")
    check(got.startswith(f"FROM|{a}|all|"), f"B nhận {got!r}")
    echo = ca.wait(lambda t: t.startswith("FROM|"), QUIET)
    check(echo is None, f"A bị vọng lại tin của chính mình: {echo!r}")

def t_msg_rieng(e):
    a, b, c = e.name("a"), e.name("b"), e.name("c")
    ca, cb, cc = e.client(login=a), e.client(login=b), e.client(login=c)
    r = ca.ask(f"MSG|{b}|bí mật", ("OK|", "ERR|"))
    check(r.startswith("OK|"), f"A nhận {r!r}, cần OK|...")
    got = cb.wait(lambda t: t.startswith("FROM|") and "bí mật" in t)
    check(got is not None and got.startswith(f"FROM|{a}|{b}|"), f"B nhận {got!r}")
    leak = cc.wait(lambda t: t.startswith("FROM|"), QUIET)
    check(leak is None, f"C (người ngoài) nhận được tin riêng: {leak!r}")

def t_msg_vang(e):
    c = e.client(login=e.name("a"))
    r = c.ask("MSG|khongcoai_" + e.tok + "|hi", ("OK|", "ERR|"))
    check(r.startswith("ERR|5"), f"nhận {r!r}, cần ERR|5")

def t_noi_dung_1000(e):
    c = e.client(login=e.name("a"))
    r = c.ask("MSG|all|" + "x" * 1000, ("OK|", "ERR|"))
    check(r.startswith("OK|"), f"nội dung đúng 1000 byte nhận {r[:30]!r}, cần OK|...")

def t_noi_dung_1001(e):
    c = e.client(login=e.name("a"))
    r = c.ask("MSG|all|" + "x" * 1001, ("OK|", "ERR|"))
    check(r.startswith("ERR|4"), f"nội dung 1001 byte nhận {r[:30]!r}, cần ERR|4")

def t_lenh_la(e):
    c = e.client(login=e.name("a"))
    r = c.ask("HELLO", ("OK|", "ERR|", "PONG|"))
    check(r.startswith("ERR|4"), f"HELLO nhận {r!r}, cần ERR|4")

def t_1300_byte(e):
    c = e.client(login=e.name("a"))
    c.s.send(b"x" * 1300)                      # gửi thẳng, vượt 1200 byte
    r = c.wait(lambda t: True, QUIET)
    check(r is None, f"server lại trả lời datagram quá lớn: {r!r}")
    e.clients.remove(c)                 # giữ lại cho ca ngay sau (cùng địa chỉ, cùng phiên)
    e.shared["c1300"] = c

def t_sau_1300(e):
    c = e.shared.pop("c1300", None)
    if c is None:
        c = Client()
    e.clients.append(c)                 # để cleanup đóng
    r = c.ask("PING|8", ("PONG|", "ERR|"))
    check(r == "PONG|8", f"sau datagram 1300 byte nhận {r!r}, cần PONG|8 (server có dừng?)")

def t_utf8_hong(e):
    c = e.client(login=e.name("a"))
    c.s.send(b"MSG|all|\xff\xfe\xfa\n")
    r = c.wait(lambda t: True, QUIET)
    check(r is None, f"server trả lời UTF-8 hỏng: {r!r}")
    r = c.ask("PING|9", ("PONG|", "ERR|"))
    check(r == "PONG|9", f"sau UTF-8 hỏng nhận {r!r}, cần PONG|9")

def t_discover(e):
    r = e.client().ask("DISCOVER", ("HERE|", "ERR|"))
    check(r.startswith("HERE|"), f"nhận {r!r}, cần HERE|<phòng>|<số người>")

def t_quit(e):
    a, b = e.name("a"), e.name("b")
    ca, cb = e.client(login=a), e.client(login=b)
    r = ca.ask("QUIT", "BYE")
    check(r == "BYE", f"nhận {r!r}, cần BYE")
    sys_msg = cb.wait(lambda t: t.startswith("SYS|") and a.lower() in t.lower())
    check(sys_msg is not None, "B không nhận SYS báo A rời phòng")
    r2 = ca.ask("QUIT", "BYE")                  # lần hai: vô hại
    check(r2 == "BYE", f"QUIT lần 2 nhận {r2!r}")


CASES = [
    # (mục đích, lệnh gửi, trả lời mong đợi, hàm)
    ("Chặn sai trình tự",            "MSG|all|chào (chưa LOGIN)",      "ERR|3|…",                 t_sai_trinh_tu),
    ("LOGIN hợp lệ",                 "LOGIN|<tên>",                    "OK|…",                    t_login_ok),
    ("LOGIN gửi lại",                "LOGIN|<tên> (lần 2)",            "OK|… (tên chỉ 1 lần)",    t_login_lai),
    ("Tên trùng (khác hoa/thường)",  "LOGIN|<TÊN> từ địa chỉ khác",    "ERR|1|…",                 t_ten_trung),
    ("Tên quá 20 ký tự",             "LOGIN|xxxxxxxxxxxxxxxxxxxxx (21)", "ERR|2|…",               t_ten_dai),
    ("WHO",                          "WHO",                            "WHO|<danh sách có tên>",  t_who),
    ("PING chưa đăng nhập",          "PING|7",                         "PONG|7",                  t_ping),
    ("MSG cả phòng",                 "MSG|all|xin chào cả phòng",      "OK|…; B nhận FROM, A không bị vọng", t_msg_chung),
    ("MSG riêng",                    "MSG|<B>|bí mật",                 "OK|…; chỉ B nhận FROM",   t_msg_rieng),
    ("Người nhận vắng mặt",          "MSG|<không có>|hi",              "ERR|5|…",                 t_msg_vang),
    ("Nội dung đúng 1000 byte",      "MSG|all|x…x (1000)",             "OK|…",                    t_noi_dung_1000),
    ("Nội dung 1001 byte",           "MSG|all|x…x (1001)",             "ERR|4|…",                 t_noi_dung_1001),
    ("Lệnh lạ khi đã đăng nhập",     "HELLO",                          "ERR|4|…",                 t_lenh_la),
    ("Datagram 1300 byte (send())",  "sock.send(b'x'*1300)",           "Bỏ qua, không trả lời",   t_1300_byte),
    ("Ngay sau 1300 byte",           "PING|8",                         "PONG|8",                  t_sau_1300),
    ("UTF-8 hỏng",                   "b'MSG|all|\\xff\\xfe' rồi PING|9", "Bỏ qua; PONG|9 sau đó", t_utf8_hong),
    ("DISCOVER",                     "DISCOVER",                       "HERE|<phòng>|<số người>", t_discover),
    ("QUIT (và lần hai)",            "QUIT, QUIT",                     "BYE, BYE; người khác nhận SYS", t_quit),
]


def run_once(k, verbose=True):
    env = Env()
    res = []
    for i, (purpose, cmd, exp, fn) in enumerate(CASES, 1):
        t = time.strftime("%H:%M:%S")
        env.n = i
        try:
            fn(env)
            res.append((i, "Đạt", ""))
        except (AssertionError, OSError) as ex:
            res.append((i, "SAI", f"{type(ex).__name__}: {ex}"))
        except Exception as ex:                       # lỗi lạ cũng không làm dừng bộ kiểm thử
            res.append((i, "SAI", f"{type(ex).__name__}: {ex}"))
        if verbose:
            r = res[-1]
            print(f"[lần {k}] {t} ca {i:>2} {r[1]:<4} {purpose}" + (f"  <- {r[2]}" if r[2] else ""), flush=True)
        try:
            env.cleanup()
        except Exception:
            pass
    return res


def main():
    global HOST, PORT, T0, TRIES
    ap = argparse.ArgumentParser(description="Kiểm thử UDP chat server")
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=9012)
    ap.add_argument("--repeat", type=int, default=1, help="số lần chạy liền nhau")
    ap.add_argument("--timeout", type=float, default=0.2, help="thời gian chờ đầu của ask()")
    ap.add_argument("--tries", type=int, default=6, help="số lần gửi tối đa của ask()")
    a = ap.parse_args()
    HOST, PORT, T0, TRIES = a.host, a.port, a.timeout, a.tries

    probe = Client()
    try:
        ask(probe.s, "PING|0", "PONG|0", timeout=0.3, tries=4)
    except TimeoutError:
        raise SystemExit("Server không trả lời PING. Đã chạy udp_chat_server.py chưa, đúng --port chưa?")
    except (ConnectionRefusedError, ConnectionResetError):
        raise SystemExit("Cổng đóng: chưa có server nào chạy ở địa chỉ/cổng này.")
    finally:
        probe.s.close()

    runs = [run_once(k + 1) for k in range(a.repeat)]

    print("\n| TT | Mục đích | Lệnh gửi | Trả lời mong đợi | Kết quả " + f"{a.repeat} lần |")
    print("|---|---|---|---|---|")
    bad = 0
    for i, (purpose, cmd, exp, _) in enumerate(CASES):
        cells = [r[i][1] for r in runs]
        bad += cells.count("SAI")
        cmd, exp = cmd.replace("|", "│"), exp.replace("|", "│")     # '│' như bảng đặc tả, không vỡ bảng
        print(f"| {i + 1} | {purpose} | {cmd} | {exp} | {' / '.join(cells)} |")
    fails = [(k + 1, r[i]) for k, r in enumerate(runs) for i in range(len(CASES)) if r[i][1] == "SAI"]
    if fails:
        print("\nCa SAI (đối chiếu giờ [lần k] với log server để giải thích):")
        for k, (i, _, why) in fails:
            print(f"  lần {k}, ca {i}: {why}")
    print(f"\nTổng: {len(CASES) * a.repeat - bad}/{len(CASES) * a.repeat} đạt")
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()